Dim wsh
Set obj = WScript.Arguments
If obj.count = 0 Then
Set wsh = CreateObject("WSCript.shell")
For i = 1 To 100
wsh.Run WScript.ScriptFullName & " " & cstr(i)
Next
Set wsh = nothing
Set obj = nothing

else
msgbox "Error!",vbCritical
set objArgs = nothing
end if