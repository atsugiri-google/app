@echo off
call shori.bat
call kugi.bat